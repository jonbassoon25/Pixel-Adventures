//Util Imports

//UI Object Imports

//Gamestate Imports

//Game Object Imports

//Game Entity Imports

//Basic Object Imports

//Template Class
export class Template {
	/*
	Notes:
		- stuff
	*/

	//*********************************************************************//
	//Static Variables


	//*********************************************************************//
	//Private Static Methods - No required JSDocs


	//*********************************************************************//
	//Public Static Methods - Must Have JSDocs


	//*********************************************************************//
	//Constructor - Must have JSDocs


	//*********************************************************************//
	//Private Methods - No required JSDocs


	//*********************************************************************//
	//Public Methods - Must have JSDocs


	//*********************************************************************//
	//Getters - No required JSDocs


	//*********************************************************************//
	//Setters - Must have JSDocs


}